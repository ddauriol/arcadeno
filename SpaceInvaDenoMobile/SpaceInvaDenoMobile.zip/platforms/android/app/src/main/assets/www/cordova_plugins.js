cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-browsersync": "0.1.7"
  };
});